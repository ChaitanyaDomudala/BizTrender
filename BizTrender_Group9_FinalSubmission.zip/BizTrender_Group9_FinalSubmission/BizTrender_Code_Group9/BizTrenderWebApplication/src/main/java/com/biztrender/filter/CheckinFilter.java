package com.biztrender.filter;

public class CheckinFilter extends SearchFilter {
	private String businessId;

	public String getBusinessId() {
		return businessId;
	}

	public void setBusinessId(String businessId) {
		this.businessId = businessId;
	}
}