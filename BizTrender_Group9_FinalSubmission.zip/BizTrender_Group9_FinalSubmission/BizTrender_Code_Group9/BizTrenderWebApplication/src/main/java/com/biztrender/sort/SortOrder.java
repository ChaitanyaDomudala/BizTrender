package com.biztrender.sort;

public enum SortOrder {

	ASC, DESC;

}
